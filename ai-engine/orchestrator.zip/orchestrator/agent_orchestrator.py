import logging
import json

from orchestrator.agents.resume_agent import resume_agent
from orchestrator.agents.jd_agent import jd_agent
from orchestrator.agents.skill_gap_agent import skill_gap_agent
from orchestrator.agents.scoring_agent import scoring_agent
from orchestrator.agents.interview_agent import interview_agent


logger = logging.getLogger(__name__)


class AgentOrchestrator:

    def execute(
            self,
            task
    ):

        result = {}

        logger.info(
            f"Starting task "
            f"{task['_id']}"
        )

        logger.info("Step 1: Analyzing Resume")
        resume_text = str(task["resumeText"])
        resume_profile = (
            resume_agent.analyze(
                resume_text
            )
        )

        result[
            "resume_profile"
        ] = resume_profile


        logger.info("Step 2: Analyzing Job Description")
        jd_profile = (
            jd_agent.analyze(
                str(task["jobDescription"])
            )
        )

        result[
            "jd_profile"
        ] = jd_profile



        logger.info("Step 3: Comparing Skill Gap")
        skill_gap_result = (
            skill_gap_agent.compare(
                resume_profile,
                jd_profile
            )
        )

        result[
            "skill_gap"
        ] = skill_gap_result


        logger.info("Step 4: Scoring Resume against Job Description")
        ats_result = (
            scoring_agent.score(
                resume_profile,
                jd_profile,
                skill_gap_result
            )
        )

        result[
            "ats"
        ] = ats_result



        logger.info("Step 5: Generating Interview Questions")
        interview_questions = (
            interview_agent.generate(
                resume_profile,
                jd_profile,
                skill_gap_result
            )
        )

        result[
            "interview_questions"
        ] = interview_questions

        logger.info(
            f"Task completed "
            f"{task['_id']}"
        )

        # print("Result: " + json.dumps(result))

        return result


agent_orchestrator = (
    AgentOrchestrator()
)