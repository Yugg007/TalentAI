import logging
from typing import Dict
from common.schemas import ResumeProfile, JDProfile, SkillGapResult
from services.llm_service import llm_service
from utils.json_parser import JsonParser

logger = logging.getLogger(__name__)


class InterviewAgent:
    """
    Orchestrates the generation of targeted interview questions by leveraging 
    structured profile assets, job expectations, and identified skill gaps.
    """

    def generate(self, resume_data: Dict, jd_data: Dict, skill_gap_data: Dict) -> Dict:
        # Enforce structural type safety via Pydantic model validation
        resume = ResumeProfile.model_validate(resume_data)
        jd = JDProfile.model_validate(jd_data)
        skill_gap = SkillGapResult.model_validate(skill_gap_data)

        # Extract targeted variables safely from the aligned schemas
        target_role = jd.job_metadata.title or "Software Engineer"
        required_skills = jd.skills.required_technical
        missing_skills = skill_gap.missing_required_skills
        
        # Format projects cleanly into text blocks for prompt clarity
        project_context = []
        for proj in resume.projects:
            tech_stack = ", ".join(proj.technologies) if proj.technologies else "Not specified"
            project_context.append(f"- Project: {proj.name}\n  Tech Stack: {tech_stack}")
        projects_str = "\n".join(project_context) if project_context else "None listed."

        # Structured, high-context prompt optimized for local reasoning models
        prompt = f"""You are an expert technical interviewer assessing a candidate for a {target_role} position.
Analyze the candidate's profile data, the role prerequisites, and their identified skill gaps below to generate highly relevant, calibrated interview questions.

[JOB REQUIREMENTS]
- Core Technical Stack: {required_skills}

[IDENTIFIED CORE SKILL GAPS]
- Missing Required Skills: {missing_skills}

[CANDIDATE PROJECTS]
{projects_str}

[INSTRUCTIONS]
1. 'technical_questions': Focus heavily on verifying their competency in core technical skills. If there are missing required skills, formulate probing questions to test if they have conceptual knowledge or tangential experience with them. Include a 'weightage' (1-5) scale representing importance.
2. 'project_questions': Deep-dive into architectural choices, scalability bottlenecks, or concurrency challenges based directly on the candidate's listed projects.
3. 'behavioral_questions': Craft situational questions testing leadership, adaptability, or how they handle ambiguity, tailored to engineering delivery.

Return raw, valid JSON matching this exact schema:
{{
  "technical_questions": [
    {{"question": "string", "weightage": 5}}
  ],
  "project_questions": [
    {{"question": "string", "weightage": 4}}
  ],
  "behavioral_questions": [
    {{"question": "string", "weightage": 3}}
  ]
}}
Do not include markdown blocks, conversational preamble, or trailing commentary. Return only valid JSON."""

        try:
            # Route payload directly to your LLM generation layer
            # Note: If your client method is named `generate` instead of `interview`, swap it below
            response = llm_service.generate(prompt)
            
            # Defensive validation check on response integrity
            if not response:
                raise ValueError("Received empty response from the local LLM service layer.")

            return JsonParser.parse(response)

        except Exception as e:
            logger.error(f"Execution failed inside InterviewAgent due to exception: {str(e)}")
            # Fallback safe structural schema return to ensure orchestration pipeline does not crash
            return {
                "technical_questions": [],
                "project_questions": [],
                "behavioral_questions": []
            }


# Thread-safe Singleton instance for orchestrator pipeline injection
interview_agent = InterviewAgent()