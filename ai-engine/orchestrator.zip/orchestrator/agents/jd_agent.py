from services.llm_service import llm_service

from utils.json_parser import JsonParser
from utils.skill_normalizer import SkillNormalizer

from common.schemas import JDProfile


class JDAgent:

    def analyze(self, jd_text):

        prompt = f"""
You are an expert ATS Job Description Parser. Your job is to extract structured, concise, and highly accurate requirement metrics from the provided Job Description (JD) text and return it in strict JSON format matching the schema below.

### Extraction Instructions:
1. "job_metadata": Extract title, company, setting ("remote", "hybrid", "on-site"), and location.
2. "experience_requirements": Extract numerical minimum and preferred years. If a range is given (e.g., "3-5 years"), minimum is 3.0, preferred is 5.0. 
3. "skills": Separate hard technical tools/languages from high-level soft skills or project methodologies (like Agile/Scrum).
4. "compensation": Extract numeric boundary constraints for salary if explicitly mentioned.

### Strict Constraints:
- Return ONLY valid, minified JSON. Do not include markdown formatting like ```json ... ```, wrapper text, preambles, or postscripts.
- If a field cannot be found or inferred from the text, set its value to null or an empty array [] as appropriate per the schema.

### JSON Schema:
{{
    "job_metadata": {{
        "title": "string",
        "company": "string",
        "work_setting": "string",
        "location": "string"
    }},
    "experience_requirements": {{
        "minimum_years": 0.0,
        "preferred_years": 0.0
    }},
    "education_requirements": [
        {{
            "degree_level": "string",
            "preferred_fields": ["string"]
        }}
    ],
    "skills": {{
        "required_technical": ["string"],
        "preferred_technical": ["string"],
        "soft_skills_methodologies": ["string"]
    }},
    "compensation": {{
        "currency": "string",
        "min_salary": 0,
        "max_salary": 0
    }}
}}

### Job Description:
{jd_text}
"""

        raw_response = llm_service.job_description(prompt)

        parsed = JsonParser.parse(raw_response)

        return parsed;


jd_agent = JDAgent()