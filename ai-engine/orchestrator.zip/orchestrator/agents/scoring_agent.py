import logging
from typing import Set, Tuple, List, Dict
from common.schemas import ResumeProfile, JDProfile, SkillGapResult, ATSResult, ScoreBreakdown
from utils.skill_normalizer import SkillNormalizer

class ScoringAgent:
    """
    Deterministic evaluation engine assigning dynamic weighted matrix indices.
    """
    # Allocation Constants
    WEIGHT_REQUIRED = 40.0
    WEIGHT_PREFERRED = 20.0
    WEIGHT_EXPERIENCE = 30.0
    WEIGHT_PROJECTS = 10.0
    
    @staticmethod
    def calculate_grade(score: float) -> str:
        if score >= 90.0: return "A"
        if score >= 75.0: return "B"
        if score >= 60.0: return "C"
        if score >= 40.0: return "D"
        return "F"

    def score(self, resume_data: Dict, jd_data: Dict, gap_result_data: Dict) -> Dict:
        resume = ResumeProfile.model_validate(resume_data)
        jd = JDProfile.model_validate(jd_data)
        gap = SkillGapResult.model_validate(gap_result_data)
        
        # 1. Skill Scores Calculation
        req_score = (gap.required_match_percentage / 100.0) * self.WEIGHT_REQUIRED
        pref_score = (gap.preferred_match_percentage / 100.0) * self.WEIGHT_PREFERRED
        
        # 2. Experience Compaction Ratio
        target_exp = jd.experience_requirements.minimum_years
        actual_exp = resume.experience_years
        
        if target_exp <= 0.0:
            exp_score = self.WEIGHT_EXPERIENCE
        else:
            exp_score = min(actual_exp / target_exp, 1.0) * self.WEIGHT_EXPERIENCE
            
        # 3. Project Scaling Matrix
        project_count = len(resume.projects)
        if project_count >= 3:
            proj_score = 10.0
        elif project_count == 2:
            proj_score = 8.0
        elif project_count == 1:
            proj_score = 5.0
        else:
            proj_score = 0.0
            
        total_score = min(100, max(0, round(req_score + pref_score + exp_score + proj_score)))
        
        # 4. Actionable Telemetry Engine (Improvements generation)
        improvements = self._generate_improvements(gap, actual_exp, target_exp)
        
        result = ATSResult(
            score=total_score,
            grade=self.calculate_grade(total_score),
            breakdown=ScoreBreakdown(
                required_skills=round(req_score, 2),
                preferred_skills=round(pref_score, 2),
                experience=round(exp_score, 2),
                projects=round(proj_score, 2)
            ),
            improvement=improvements
        )
        return result.model_dump()

    def _generate_improvements(self, gap: SkillGapResult, actual_exp: float, target_exp: float) -> List[str]:
        actions = []
        if gap.missing_required_skills:
            skills_str = ", ".join(gap.missing_required_skills[:3])
            actions.append(f"Acquire missing primary core competencies: [{skills_str}].")
            
        if actual_exp < target_exp:
            delta = round(target_exp - actual_exp, 1)
            actions.append(f"Deficit of {delta} years targeted industry domain experience relative to expectations.")
            
        if not gap.matched_preferred_skills and gap.missing_preferred_skills:
            actions.append("Incorporate secondary preferred tools/methodologies to secure higher tier rank matching.")
        return actions

# Thread-safe Singleton instances for dependency injection pipelines
scoring_agent = ScoringAgent()