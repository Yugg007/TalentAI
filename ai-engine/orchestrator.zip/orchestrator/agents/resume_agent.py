import json

from services.llm_service import llm_service
from utils.json_parser import JsonParser
from utils.skill_normalizer import SkillNormalizer

from common.schemas import ResumeProfile


class ResumeAgent:

    def analyze(self, resume_text):

        prompt = f"""
You are an expert ATS (Applicant Tracking System) Resume Parser. Your job is to extract structured, concise, and highly accurate information from the provided raw resume text and return it in strict JSON format matching the schema details exactly.

### Extraction Instructions:
1. "experience_years": Calculate the total professional experience in years based on the start and end dates of employment. Round to the nearest one decimal place (e.g., 3.0). Do not include internship durations unless no other experience exists.
2. "experience": Array of objects. Extract: "company", "role", "duration" (e.g., "July 2023 - Present"), and "achievements" (an array of high-impact strings highlighting metrics, technical overhauls, or tech used). Ensure this is populated with bullet points from the text.
3. "projects": Array of objects. Extract: "name", "duration", "technologies" (array of strings), and "achievements" (an array of concise 1-2 sentence summaries highlighting architecture or optimizations).
4. "education": Array of objects. Extract: "institution", "degree", and "duration" (e.g., "Jul 2019 - May 2023").
5. "required_skills" vs "preferred_skills": Put all concrete core technical tools, languages, and frameworks into "required_skills", and soft skills, concepts, or high-level methodologies (like System Design, Concurrency) into "preferred_skills".

### Strict Constraints:
- Return ONLY valid, minified JSON. Do not include markdown formatting like ```json ... ```, wrapper text, preambles, or postscripts.
- Do not leave arrays or object strings empty if relevant data exists in the text. Ensure all achievements for experience and projects are thoroughly extracted.
- If a field cannot be found, set its value to null or an empty array [] as appropriate per the schema.

### JSON Schema:
{{
    "required_skills": ["string"],
    "preferred_skills": ["string"],
    "experience_years": 0.0,
    "experience": [
        {{
            "company": "string",
            "role": "string",
            "duration": "string",
            "achievements": ["string"]
        }}
    ],
    "projects": [
        {{
            "name": "string",
            "duration": "string",
            "technologies": ["string"],
            "achievements": ["string"]
        }}
    ],
    "education": [
        {{
            "institution": "string",
            "degree": "string",
            "duration": "string"
        }}
    ]
}}

### Resume Text:
{resume_text}
"""

        raw_response = llm_service.resume(prompt)

        parsed = JsonParser.parse(raw_response)

        return parsed


resume_agent = ResumeAgent()