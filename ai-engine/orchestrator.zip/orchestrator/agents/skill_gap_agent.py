import logging
from typing import Set, Tuple, List, Dict
from common.schemas import ResumeProfile, JDProfile, SkillGapResult, ATSResult, ScoreBreakdown
from utils.skill_normalizer import SkillNormalizer

logger = logging.getLogger(__name__)

class SkillGapAgent:
    """
    Evaluates alignment between Candidate Assets and Job Requirements.
    Optimized utilizing O(1) hash maps for fuzzy normalizations.
    """
    
    def compare(self, resume_data: Dict, jd_data: Dict) -> Dict:
        # Type-safe parsing guarantees structure consistency
        resume = ResumeProfile.model_validate(resume_data)
        jd = JDProfile.model_validate(jd_data)
        
        # Aggregate candidate footprint
        candidate_all_skills = set(resume.required_skills) | set(resume.preferred_skills)
        
        # Build normalized look-up registry to eliminate O(N * M) iterative scans
        normalized_candidate_registry = {SkillNormalizer.normalize(s): s for s in candidate_all_skills if s}

        # Match dependencies
        matched_req, missing_req = self._partition_skills(jd.skills.required_technical, normalized_candidate_registry, candidate_all_skills)
        matched_pref, missing_pref = self._partition_skills(jd.skills.preferred_technical, normalized_candidate_registry, candidate_all_skills)
        
        # Trace surplus engineering value
        jd_total_skills_set = set(jd.skills.required_technical) | set(jd.skills.preferred_technical)
        additional_skills = list(candidate_all_skills - jd_total_skills_set)
        
        # Standardize calculations
        req_pct = round((len(matched_req) / len(jd.skills.required_technical) * 100.0), 2) if jd.skills.required_technical else 100.0
        pref_pct = round((len(matched_pref) / len(jd.skills.preferred_technical) * 100.0), 2) if jd.skills.preferred_technical else 100.0
        
        result = SkillGapResult(
            matched_required_skills=matched_req,
            missing_required_skills=missing_req,
            matched_preferred_skills=matched_pref,
            missing_preferred_skills=missing_pref,
            additional_skills=additional_skills,
            required_match_percentage=req_pct,
            preferred_match_percentage=pref_pct
        )
        return result.model_dump()

    def _partition_skills(self, target_skills: List[str], normalized_registry: Dict[str, str], raw_set: Set[str]) -> Tuple[List[str], List[str]]:
        matched, missing = [], []
        for skill in target_skills:
            if not skill:
                continue
            norm_skill = SkillNormalizer.normalize(skill)
            
            # Exact Match -> O(1)
            if skill in raw_set:
                matched.append(skill)
            # Normalized Fast-Track -> O(1)
            elif norm_skill in normalized_registry:
                matched.append(skill)
            # Fallback Fuzzy-Match Evaluator
            elif SkillNormalizer.fuzzy_match(skill, raw_set):
                matched.append(skill)
            else:
                missing.append(skill)
        return matched, missing
    
skill_gap_agent = SkillGapAgent()